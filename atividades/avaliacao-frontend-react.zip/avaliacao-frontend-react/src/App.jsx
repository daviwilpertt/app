import './App.css';
import AddLista from './componentes/AddLista/AddLista';


function App() {
  return <>
    
      <AddLista />
    
  </>;
}

export default App;
