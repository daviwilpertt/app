import './OlaMundo.css';

const OlaMundo = () => {
  return <div className='olaMundo'>Olá, Mundo!!</div>;
};
export default OlaMundo;
